<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Nachklang_Cart_Icon_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'nachklang_cart_icon'; }
    public function get_title() { return __( 'Nachklang Cart Icon + Side Cart', 'mw-elementor-widgets' ); }
    public function get_icon() { return 'eicon-bag-medium'; }
    public function get_categories() { return [ 'general' ]; }
    public function get_script_depends() { return [ 'nachklang-cart-js' ]; }
    public function get_style_depends() { return [ 'nachklang-cart-css' ]; }

    protected function _register_controls() {
        $this->start_controls_section('content_section', [
            'label' => __( 'Cart Icon / Side Cart', 'mw-elementor-widgets' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('cart_url', [
            'label' => __( 'Warenkorb-Seite URL', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => '/warenkorb',
        ]);
        $this->add_control('checkout_url', [
            'label' => __( 'Checkout URL Placeholder', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::URL,
            'description' => 'Später Webapp/Stripe Checkout Endpoint oder Seite eintragen. Aktuell optional.',
        ]);
        $this->add_control('free_shipping_text', [
            'label' => __( 'Hinweis oben', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Sie zahlen keine Lieferkosten',
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $cart_url = ! empty( $settings['cart_url']['url'] ) ? $settings['cart_url']['url'] : home_url( '/warenkorb/' );
        $checkout_url = ! empty( $settings['checkout_url']['url'] ) ? $settings['checkout_url']['url'] : '';
        ?>
        <div class="nk-cart-widget" data-checkout-url="<?php echo esc_url( $checkout_url ); ?>" data-cart-url="<?php echo esc_url( $cart_url ); ?>">
            <button type="button" class="nk-cart-trigger" aria-label="Warenkorb öffnen">
                <span class="nk-cart-icon-svg" aria-hidden="true">🛒</span>
                <span class="nk-cart-badge" data-nk-cart-count>0</span>
            </button>

            <div class="nk-cart-overlay" data-nk-cart-close></div>
            <aside class="nk-side-cart" aria-hidden="true">
                <button type="button" class="nk-side-cart-close" data-nk-cart-close aria-label="Warenkorb schliessen">×</button>
                <h3>Dein Warenkorb</h3>
                <p class="nk-shipping-note"><?php echo esc_html( $settings['free_shipping_text'] ); ?></p>
                <div class="nk-side-cart-items" data-nk-cart-items></div>
                <div class="nk-cart-empty" data-nk-cart-empty>Dein Warenkorb ist leer.</div>
                <div class="nk-cart-summary">
                    <div><span>Zwischensumme</span><strong data-nk-cart-subtotal>€ 0,00</strong></div>
                    <small>Inklusive MwSt. Versand wird später berechnet.</small>
                    <button type="button" class="nk-checkout-btn" data-nk-checkout>Zur Kasse gehen</button>
                    <a class="nk-view-cart-btn" href="<?php echo esc_url( $cart_url ); ?>">Warenkorb ansehen</a>
                </div>
            </aside>
        </div>
        <?php
    }
}
