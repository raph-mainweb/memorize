<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Nachklang_Cart_Page_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'nachklang_cart_page'; }
    public function get_title() { return __( 'Nachklang Warenkorb Seite', 'mw-elementor-widgets' ); }
    public function get_icon() { return 'eicon-product-pages'; }
    public function get_categories() { return [ 'general' ]; }
    public function get_script_depends() { return [ 'nachklang-cart-js' ]; }
    public function get_style_depends() { return [ 'nachklang-cart-css' ]; }

    protected function _register_controls() {
        $this->start_controls_section('content_section', [
            'label' => __( 'Warenkorb Seite', 'mw-elementor-widgets' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('shop_url', [
            'label' => __( 'Zurück zum Shop URL', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::URL,
            'placeholder' => '/shop',
        ]);
        $this->add_control('checkout_url', [
            'label' => __( 'Checkout URL Placeholder', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::URL,
            'description' => 'Später Webapp/Stripe Checkout Endpoint oder Seite eintragen. Aktuell optional.',
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $shop_url = ! empty( $settings['shop_url']['url'] ) ? $settings['shop_url']['url'] : home_url( '/shop/' );
        $checkout_url = ! empty( $settings['checkout_url']['url'] ) ? $settings['checkout_url']['url'] : '';
        ?>
        <section class="nk-cart-page" data-checkout-url="<?php echo esc_url( $checkout_url ); ?>">
            <div class="nk-cart-page-head">
                <h1>Dein Warenkorb</h1>
                <a href="<?php echo esc_url( $shop_url ); ?>">Zurück zum Shop</a>
            </div>
            <div class="nk-cart-page-table">
                <div class="nk-cart-page-header">
                    <span>Produkt</span><span>Preis</span><span>Menge</span><span>Total</span>
                </div>
                <div data-nk-cart-page-items></div>
                <div class="nk-cart-empty nk-cart-page-empty" data-nk-cart-empty>Dein Warenkorb ist leer.</div>
            </div>
            <div class="nk-cart-page-summary">
                <div><span>Zwischensumme</span><strong data-nk-cart-subtotal>€ 0,00</strong></div>
                <small>Inklusive MwSt. Versand wird später berechnet.</small>
                <button type="button" class="nk-checkout-btn" data-nk-checkout>Zur Kasse gehen</button>
            </div>
        </section>
        <?php
    }
}
