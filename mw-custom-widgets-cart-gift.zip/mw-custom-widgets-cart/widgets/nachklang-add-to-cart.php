<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Nachklang_Add_To_Cart_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'nachklang_add_to_cart'; }
    public function get_title() { return __( 'Nachklang Add to Cart', 'mw-elementor-widgets' ); }
    public function get_icon() { return 'eicon-cart'; }
    public function get_categories() { return [ 'general' ]; }
    public function get_script_depends() { return [ 'nachklang-cart-js' ]; }
    public function get_style_depends() { return [ 'nachklang-cart-css' ]; }

    protected function _register_controls() {
        $this->start_controls_section('content_section', [
            'label' => __( 'Button', 'mw-elementor-widgets' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]);
        $this->add_control('button_text', [
            'label' => __( 'Button Text', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'In den Warenkorb',
        ]);
        $this->add_control('show_quantity', [
            'label' => __( 'Menge anzeigen', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => '',
        ]);
        $this->add_control('open_cart', [
            'label' => __( 'Side Cart nach Klick öffnen', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'yes',
        ]);
        $this->add_control('show_purchase_type', [
            'label' => __( 'Auswahl „Für mich / Geschenk“ anzeigen', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::SWITCHER,
            'return_value' => 'yes',
            'default' => 'yes',
        ]);
        $this->add_control('purchase_label', [
            'label' => __( 'Überschrift Auswahl', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Für wen ist das Medaillon?',
            'condition' => [ 'show_purchase_type' => 'yes' ],
        ]);
        $this->add_control('self_label', [
            'label' => __( 'Option 1 Label', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Für mich',
            'condition' => [ 'show_purchase_type' => 'yes' ],
        ]);
        $this->add_control('self_description', [
            'label' => __( 'Option 1 Beschreibung', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Ich aktiviere das Medaillon später selbst.',
            'condition' => [ 'show_purchase_type' => 'yes' ],
        ]);
        $this->add_control('gift_label', [
            'label' => __( 'Option 2 Label', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Als Geschenk',
            'condition' => [ 'show_purchase_type' => 'yes' ],
        ]);
        $this->add_control('gift_description', [
            'label' => __( 'Option 2 Beschreibung', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'Die beschenkte Person löst den QR-Code mit Aktivierungscode ein.',
            'condition' => [ 'show_purchase_type' => 'yes' ],
        ]);
        $this->add_control('variant_meta_key', [
            'label' => __( 'ACF/Meta Key Variant ID', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'variant_id',
        ]);
        $this->add_control('price_meta_key', [
            'label' => __( 'ACF/Meta Key Preis', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'price',
        ]);
        $this->add_control('image_meta_key', [
            'label' => __( 'ACF/Meta Key Bild URL', 'mw-elementor-widgets' ),
            'type' => \Elementor\Controls_Manager::TEXT,
            'default' => 'image_url',
        ]);
        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $post_id = get_the_ID();

        $variant_key = ! empty( $settings['variant_meta_key'] ) ? $settings['variant_meta_key'] : 'variant_id';
        $price_key   = ! empty( $settings['price_meta_key'] ) ? $settings['price_meta_key'] : 'price';
        $image_key   = ! empty( $settings['image_meta_key'] ) ? $settings['image_meta_key'] : 'image_url';

        $variant_id = get_post_meta( $post_id, $variant_key, true );
        $price      = get_post_meta( $post_id, $price_key, true );
        $image_url  = get_post_meta( $post_id, $image_key, true );
        $handle     = get_post_meta( $post_id, 'handle', true );
        $shopify_id = get_post_meta( $post_id, 'shopify_id', true );
        $product_type = get_post_meta( $post_id, 'product_type', true );

        $payload = [
            'post_id'      => $post_id,
            'variant_id'   => (string) $variant_id,
            'shopify_id'   => (string) $shopify_id,
            'handle'       => (string) $handle,
            'title'        => get_the_title( $post_id ),
            'url'          => get_permalink( $post_id ),
            'image_url'    => (string) $image_url,
            'price'        => (string) $price,
            'product_type' => (string) $product_type,
            'purchase_type' => 'self',
            'purchase_label' => ! empty( $settings['self_label'] ) ? (string) $settings['self_label'] : 'Für mich',
        ];

        $choice_name = 'nk_purchase_type_' . $this->get_id();

        echo '<div class="nk-add-to-cart-wrap">';
        if ( $settings['show_purchase_type'] === 'yes' ) {
            echo '<div class="nk-purchase-choice" role="radiogroup" aria-label="' . esc_attr( $settings['purchase_label'] ) . '">';
            echo '<div class="nk-purchase-choice-title">' . esc_html( $settings['purchase_label'] ) . '</div>';
            echo '<label class="nk-purchase-option"><input type="radio" name="' . esc_attr( $choice_name ) . '" value="self" data-label="' . esc_attr( $settings['self_label'] ) . '" checked><span><strong>' . esc_html( $settings['self_label'] ) . '</strong><small>' . esc_html( $settings['self_description'] ) . '</small></span></label>';
            echo '<label class="nk-purchase-option"><input type="radio" name="' . esc_attr( $choice_name ) . '" value="gift" data-label="' . esc_attr( $settings['gift_label'] ) . '"><span><strong>' . esc_html( $settings['gift_label'] ) . '</strong><small>' . esc_html( $settings['gift_description'] ) . '</small></span></label>';
            echo '</div>';
        }
        if ( $settings['show_quantity'] === 'yes' ) {
            echo '<div class="nk-qty-control nk-add-qty"><button type="button" class="nk-qty-minus" aria-label="Menge reduzieren">−</button><input class="nk-add-to-cart-qty" type="number" min="1" step="1" value="1" /><button type="button" class="nk-qty-plus" aria-label="Menge erhöhen">+</button></div>';
        }
        echo '<button type="button" class="nk-add-to-cart-btn" data-open-cart="' . esc_attr( $settings['open_cart'] === 'yes' ? '1' : '0' ) . '" data-product="' . esc_attr( wp_json_encode( $payload ) ) . '">' . esc_html( $settings['button_text'] ) . '</button>';
        if ( empty( $variant_id ) && \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            echo '<p class="nk-cart-note">Hinweis: Keine variant_id am aktuellen Produkt gefunden.</p>';
        }
        echo '</div>';
    }
}
