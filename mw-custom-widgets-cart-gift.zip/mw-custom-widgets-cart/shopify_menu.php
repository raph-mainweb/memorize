<?php

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
  exit;
}

class Shopify_Menu extends \Elementor\Widget_Base {

    // Widget Identifikation
    public function get_name() {
        return 'shopify_style_menu';
    }

    public function get_title() {
        return __( 'Shopify Style Menu', 'elementor-menu-widget' );
    }

    public function get_icon() {
        return 'eicon-nav-menu';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    // Widget Einstellungen
    protected function _register_controls() {
        
        // Menü Inhalt Sektion
        $this->start_controls_section(
            'menu_content_section',
            [
                'label' => __( 'Menü Inhalt', 'elementor-menu-widget' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // WordPress Menü Auswahl
        $menus = wp_get_nav_menus();
        $menu_options = [];
        foreach ( $menus as $menu ) {
            $menu_options[ $menu->term_id ] = $menu->name;
        }

        $this->add_control(
            'selected_menu',
            [
                'label' => __( 'Wähle ein Menü', 'elementor-menu-widget' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => $menu_options,
                'default' => '',
            ]
        );

        $this->add_control(
            'show_go_to_link',
            [
                'label' => __( 'Zeige "Gehe zu" Links', 'elementor-menu-widget' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Ja', 'elementor-menu-widget' ),
                'label_off' => __( 'Nein', 'elementor-menu-widget' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_menu_images',
            [
                'label' => __( 'Zeige Menü Bilder', 'elementor-menu-widget' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Ja', 'elementor-menu-widget' ),
                'label_off' => __( 'Nein', 'elementor-menu-widget' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'description' => __( 'Zeigt Bilder an, die mit dem Simple Menu Images Plugin hinzugefügt wurden', 'elementor-menu-widget' ),
            ]
        );

        $this->add_control(
            'image_size',
            [
                'label' => __( 'Bildgröße (px)', 'elementor-menu-widget' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 16,
                        'max' => 64,
                        'step' => 2,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'condition' => [
                    'show_menu_images' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'menu_class',
            [
                'label' => __( 'CSS Klasse', 'elementor-menu-widget' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => 'shopify-menu',
                'description' => __( 'Zusätzliche CSS-Klasse für das Menü', 'elementor-menu-widget' ),
            ]
        );

        $this->end_controls_section();
    }

    // Widget Ausgabe
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        if ( empty( $settings['selected_menu'] ) ) {
            echo '<p>Bitte wähle ein Menü aus den Widget-Einstellungen.</p>';
            return;
        }

        $menu_items = wp_get_nav_menu_items( $settings['selected_menu'] );
        
        if ( empty( $menu_items ) ) {
            echo '<p>Das gewählte Menü ist leer.</p>';
            return;
        }

        // Menü Items hierarchisch organisieren
        $menu_tree = $this->build_menu_tree( $menu_items );
        
        $menu_class = !empty( $settings['menu_class'] ) ? esc_attr( $settings['menu_class'] ) : 'shopify-menu';
        
        // CSS für Bilder hinzufügen
        if ( $settings['show_menu_images'] === 'yes' ) {
            $image_size = $settings['image_size']['size'];
            echo '<style>
                .menu-item-image {
                    display: inline-block;
                    width: ' . $image_size . 'px;
                    height: ' . $image_size . 'px;
                    vertical-align: middle;
                    object-fit: cover;
                }
            </style>';
        }
        
        echo '<nav class="nav-sidebar__container nav-sidebar ' . $menu_class . '">';
        echo '<ul class="nav-sidebar__menu has-dropdown menu-list nav-sidebar__background" role="list">';
        
        foreach ( $menu_tree as $item ) {
            $this->render_menu_item( $item, $settings );
        }
        
        echo '</ul>';
        echo '</nav>';
    }

    // Hilfsfunktion um Menü-Bild zu erhalten
    private function get_menu_item_image( $item_id, $settings ) {
        if ( $settings['show_menu_images'] !== 'yes' ) {
            return '';
        }
        
        $image_url = get_post_meta( $item_id, '_menu_item_image', true );
        
        if ( !empty( $image_url ) ) {
            return '<img src="' . esc_url( $image_url ) . '" alt="" class="menu-item-image" />';
        }
        
        return '';
    }

    // Menü Baum erstellen
    private function build_menu_tree( $menu_items ) {
        $menu_tree = [];
        $menu_by_id = [];
        
        // Alle Items nach ID indexieren
        foreach ( $menu_items as $item ) {
            $menu_by_id[ $item->ID ] = $item;
            $menu_by_id[ $item->ID ]->children = [];
        }
        
        // Hierarchie aufbauen
        foreach ( $menu_items as $item ) {
            if ( $item->menu_item_parent == 0 ) {
                $menu_tree[] = $menu_by_id[ $item->ID ];
            } else {
                $menu_by_id[ $item->menu_item_parent ]->children[] = $menu_by_id[ $item->ID ];
            }
        }
        
        return $menu_tree;
    }

    // Einzelnes Menü Item rendern
    private function render_menu_item( $item, $settings, $level = 0 ) {
        $has_children = !empty( $item->children );
        $is_current = ( get_the_ID() == $item->object_id );
        $is_child_active = $this->is_child_active( $item );
        $active_class = ( $is_current || $is_child_active ) ? ' nav-sidebar__item--active' : '';
        $first_class = ( $level == 0 ) ? ' nav-sidebar__item--first' : '';
        
        // Bild für dieses Menü-Item holen
        $menu_image = $this->get_menu_item_image( $item->ID, $settings );
        $has_image_class = !empty( $menu_image ) ? ' has-image' : '';
        
        echo '<li>';
        
        if ( $has_children ) {
            echo '<details id="Details-nav-sidebar-menu-item-' . $item->ID . '">';
            echo '<summary class="nav-sidebar__item menu-list__item nav-link nav-link--text nav-sidebar__item--parent heading-small' . $active_class . $first_class . $has_image_class . ' width-full">';
            echo $menu_image;
            echo esc_html( $item->title );
            echo '<svg class="icon-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9,18 15,12 9,6"></polyline></svg>';
            echo '</summary>';
            
            echo '<div id="link-' . esc_attr( sanitize_title( $item->title ) ) . '" class="nav-sidebar__dropdown has-dropdown background-gradient reduced-motion" tabindex="-1">';
            echo '<div class="nav-sidebar__dropdown-inner nav-sidebar__background">';
            echo '<button class="nav-sidebar__back-button nav-link nav-link--text" aria-expanded="true">';
            echo '<svg class="icon-back" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15,18 9,12 15,6"></polyline></svg>';
            echo $menu_image;
            echo esc_html( $item->title );
            echo '</button>';
            
            echo '<ul class="nav-sidebar__menu menu-list" role="list" tabindex="-1">';
            
            // "Gehe zu" Link wenn aktiviert und URL vorhanden
            if ( $settings['show_go_to_link'] === 'yes' && !empty( $item->url ) ) {
                echo '<li>';
                echo '<a href="' . esc_url( $item->url ) . '" class="nav-sidebar__item nav-link nav-link--text menu-list__item width-full collection-link' . $has_image_class . '">';
                echo $menu_image;
                echo 'Gehe zu ' . esc_html( $item->title );
                echo '</a>';
                echo '</li>';
            }
            
            // Kind-Elemente rendern
            foreach ( $item->children as $index => $child ) {
                $this->render_child_item( $child, $settings, $index, count( $item->children ) );
            }
            
            echo '</ul>';
            echo '</div>';
            echo '</div>';
            echo '</details>';
        } else {
            // Einfacher Link ohne Kinder
            echo '<a href="' . esc_url( $item->url ) . '" class="nav-sidebar__item menu-list__item nav-link nav-link--text nav-sidebar__item--parent heading-small' . $active_class . $first_class . $has_image_class . ' width-full"' . ( $is_current ? ' aria-current="page"' : '' ) . '>';
            echo $menu_image;
            echo esc_html( $item->title );
            echo '</a>';
        }
        
        echo '</li>';
    }

    // Kind-Element rendern (für Untermenüs)
    private function render_child_item( $item, $settings, $index, $total_items ) {
        $has_children = !empty( $item->children );
        $is_current = ( get_the_ID() == $item->object_id );
        $is_child_active = $this->is_child_active( $item );
        $active_class = ( $is_current || $is_child_active ) ? ' nav-sidebar__item--active' : '';
        $last_class = ( $index === $total_items - 1 ) ? ' nav-sidebar__item--last' : '';
        
        // Bild für dieses Untermenü-Item holen
        $menu_image = $this->get_menu_item_image( $item->ID, $settings );
        $has_image_class = !empty( $menu_image ) ? ' has-image' : '';
        
        echo '<li>';
        
        if ( $has_children ) {
            // Untermenü mit weiteren Kindern
            echo '<details id="Details-nav-sidebar-submenu-' . $item->ID . '">';
            echo '<summary class="nav-sidebar__item nav-link nav-link--text menu-list__item' . $active_class . $last_class . $has_image_class . ' width-full position-relative">';
            echo $menu_image;
            echo esc_html( $item->title );
            echo '<svg class="icon-caret" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9,18 15,12 9,6"></polyline></svg>';
            echo '</summary>';
            
            echo '<div id="childlink-' . esc_attr( sanitize_title( $item->title ) ) . '" class="nav-sidebar__dropdown has-dropdown background-gradient child_dropdown reduced-motion">';
            echo '<div class="nav-sidebar__dropdown-inner nav-sidebar__background">';
            echo '<button class="nav-sidebar__back-button nav-link nav-link--text" aria-expanded="true">';
            echo '<svg class="icon-back" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15,18 9,12 15,6"></polyline></svg>';
            echo $menu_image;
            echo esc_html( $item->title );
            echo '</button>';
            
            echo '<ul class="nav-sidebar__menu menu-list" role="list" tabindex="-1">';
            
            // "Gehe zu" Link für Untermenü
            if ( $settings['show_go_to_link'] === 'yes' && !empty( $item->url ) ) {
                echo '<li>';
                echo '<a href="' . esc_url( $item->url ) . '" class="nav-sidebar__item nav-link nav-link--text menu-list__item width-full collection-link' . $has_image_class . '">';
                echo $menu_image;
                echo 'Gehe zu ' . esc_html( $item->title );
                echo '</a>';
                echo '</li>';
            }
            
            // Enkel-Elemente rendern
            foreach ( $item->children as $grandchild_index => $grandchild ) {
                $grandchild_is_current = ( get_the_ID() == $grandchild->object_id );
                $grandchild_active_class = $grandchild_is_current ? ' nav-sidebar__item--active' : '';
                $grandchild_last_class = ( $grandchild_index === count( $item->children ) - 1 ) ? ' nav-sidebar__item--last' : '';
                
                // Bild für Enkel-Element
                $grandchild_image = $this->get_menu_item_image( $grandchild->ID, $settings );
                $grandchild_has_image_class = !empty( $grandchild_image ) ? ' has-image' : '';
                
                echo '<li>';
                echo '<a href="' . esc_url( $grandchild->url ) . '" class="nav-sidebar__item nav-link nav-link--text menu-list__item' . $grandchild_active_class . $grandchild_last_class . $grandchild_has_image_class . ' width-full position-relative"' . ( $grandchild_is_current ? ' aria-current="page"' : '' ) . '>';
                echo $grandchild_image;
                echo esc_html( $grandchild->title );
                echo '</a>';
                echo '</li>';
            }
            
            echo '</ul>';
            echo '</div>';
            echo '</div>';
            echo '</details>';
        } else {
            // Einfaches Untermenü-Element
            echo '<a href="' . esc_url( $item->url ) . '" class="nav-sidebar__item nav-link nav-link--text menu-list__item' . $active_class . $last_class . $has_image_class . ' width-full position-relative"' . ( $is_current ? ' aria-current="page"' : '' ) . '>';
            echo $menu_image;
            echo esc_html( $item->title );
            echo '</a>';
        }
        
        echo '</li>';
    }

    // Prüft ob ein Kind-Element aktiv ist (für Parent-Active-Status)
    private function is_child_active( $item ) {
        if ( empty( $item->children ) ) {
            return false;
        }
        
        $current_page_id = get_the_ID();
        $current_url = home_url( $_SERVER['REQUEST_URI'] );
        
        foreach ( $item->children as $child ) {
            // Direkte Übereinstimmung mit der aktuellen Seite
            if ( $child->object_id == $current_page_id ) {
                return true;
            }
            
            // URL-Übereinstimmung prüfen
            if ( rtrim( $child->url, '/' ) === rtrim( $current_url, '/' ) ) {
                return true;
            }
            
            // Rekursiv für Enkel-Elemente prüfen
            if ( $this->is_child_active( $child ) ) {
                return true;
            }
        }
        
        return false;
    }
}
?>