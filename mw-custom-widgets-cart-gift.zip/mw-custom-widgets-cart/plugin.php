<?php
/**
 * Plugin Name: MW Elementor Widgets
 * Description: Custom Elementor widgets inkl. Nachklang Cart Widgets.
 * Version: 4.0
 * Author: Mainweb
 * Author URI: https://mainweb.ch/
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'MW_EW_PATH', plugin_dir_path( __FILE__ ) );
define( 'MW_EW_URL', plugin_dir_url( __FILE__ ) );

function mw_ew_register_assets() {
    wp_register_style(
        'nachklang-cart-css',
        MW_EW_URL . 'assets/nachklang-cart.css',
        [],
        '1.0.0'
    );

    wp_register_script(
        'nachklang-cart-js',
        MW_EW_URL . 'assets/nachklang-cart.js',
        [],
        '1.0.0',
        true
    );

    wp_localize_script( 'nachklang-cart-js', 'NK_CART_CONFIG', [
        'storageKey' => 'nachklang_cart_v1',
        'cartIdKey'  => 'nachklang_cart_id',
        'currency'   => 'EUR',
        'locale'     => get_locale(),
        'siteUrl'    => home_url( '/' ),
    ] );
}
add_action( 'wp_enqueue_scripts', 'mw_ew_register_assets' );
add_action( 'elementor/frontend/after_register_scripts', 'mw_ew_register_assets' );

function register_custom_widget() {
    if ( ! did_action( 'elementor/loaded' ) ) {
        return;
    }

    require_once MW_EW_PATH . 'widget.php';
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new My_Custom_Widget() );

    require_once MW_EW_PATH . 'shopify_menu.php';
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Shopify_Menu() );

    require_once MW_EW_PATH . 'widgets/nachklang-add-to-cart.php';
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Nachklang_Add_To_Cart_Widget() );

    require_once MW_EW_PATH . 'widgets/nachklang-cart-icon.php';
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Nachklang_Cart_Icon_Widget() );

    require_once MW_EW_PATH . 'widgets/nachklang-cart-page.php';
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Nachklang_Cart_Page_Widget() );
}
add_action( 'elementor/widgets/widgets_registered', 'register_custom_widget' );
