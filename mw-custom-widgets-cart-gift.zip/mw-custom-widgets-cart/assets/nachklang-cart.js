(function () {
  'use strict';

  const config = window.NK_CART_CONFIG || {};
  const storageKey = config.storageKey || 'nachklang_cart_v1';
  const cartIdKey = config.cartIdKey || 'nachklang_cart_id';
  const currency = config.currency || 'EUR';

  const money = (value) => {
    const amount = Number(String(value || 0).replace(',', '.')) || 0;
    try {
      return new Intl.NumberFormat('de-DE', { style: 'currency', currency }).format(amount);
    } catch (e) {
      return '€ ' + amount.toFixed(2).replace('.', ',');
    }
  };

  const uid = () => 'cart_' + Math.random().toString(36).slice(2) + Date.now().toString(36);

  const readCart = () => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (!raw) return { cart_id: localStorage.getItem(cartIdKey) || uid(), items: [] };
      const cart = JSON.parse(raw);
      cart.items = Array.isArray(cart.items) ? cart.items : [];
      cart.cart_id = cart.cart_id || localStorage.getItem(cartIdKey) || uid();
      return cart;
    } catch (e) {
      return { cart_id: uid(), items: [] };
    }
  };

  const saveCart = (cart) => {
    cart.updated_at = new Date().toISOString();
    localStorage.setItem(storageKey, JSON.stringify(cart));
    localStorage.setItem(cartIdKey, cart.cart_id);
    window.dispatchEvent(new CustomEvent('nk-cart:updated', { detail: cart }));
    return cart;
  };

  const normalizeProduct = (product) => {
    const price = Number(String(product.price || 0).replace(',', '.')) || 0;
    const purchaseType = product.purchase_type || 'self';
    const baseKey = product.variant_id || product.post_id || product.handle || String(Date.now());
    return {
      key: baseKey + '|' + purchaseType,
      post_id: product.post_id || '',
      variant_id: product.variant_id || '',
      shopify_id: product.shopify_id || '',
      handle: product.handle || '',
      title: product.title || 'Produkt',
      url: product.url || '#',
      image_url: product.image_url || '',
      price,
      product_type: product.product_type || '',
      purchase_type: purchaseType,
      purchase_label: product.purchase_label || (purchaseType === 'gift' ? 'Als Geschenk' : 'Für mich')
    };
  };

  const totals = (cart) => {
    const count = cart.items.reduce((sum, item) => sum + Number(item.quantity || 0), 0);
    const subtotal = cart.items.reduce((sum, item) => sum + (Number(item.price || 0) * Number(item.quantity || 0)), 0);
    return { count, subtotal };
  };

  const api = {
    getCart() { return readCart(); },
    add(product, quantity) {
      const cart = readCart();
      const item = normalizeProduct(product);
      const qty = Math.max(1, parseInt(quantity || 1, 10));
      const existing = cart.items.find(i => i.key === item.key);
      if (existing) {
        existing.quantity = Number(existing.quantity || 0) + qty;
      } else {
        cart.items.push({ ...item, quantity: qty });
      }
      return saveCart(cart);
    },
    update(key, quantity) {
      const cart = readCart();
      const qty = Math.max(0, parseInt(quantity || 0, 10));
      if (qty <= 0) {
        cart.items = cart.items.filter(i => i.key !== key);
      } else {
        const item = cart.items.find(i => i.key === key);
        if (item) item.quantity = qty;
      }
      return saveCart(cart);
    },
    remove(key) {
      const cart = readCart();
      cart.items = cart.items.filter(i => i.key !== key);
      return saveCart(cart);
    },
    clear() { return saveCart({ cart_id: uid(), items: [] }); },
    totals,
    exportPayload() {
      const cart = readCart();
      return { ...cart, totals: totals(cart) };
    }
  };

  window.NKCart = api;

  const itemTemplate = (item, isPage) => {
    const total = Number(item.price || 0) * Number(item.quantity || 0);
    const img = item.image_url ? `<img src="${escapeAttr(item.image_url)}" alt="" />` : '<span class="nk-cart-placeholder"></span>';
    const title = `<a href="${escapeAttr(item.url || '#')}">${escapeHtml(item.title)}</a>`;
    const purchase = item.purchase_label ? `<div class="nk-cart-purchase-type">${escapeHtml(item.purchase_label)}</div>` : '';
    const controls = `<div class="nk-qty-control"><button type="button" data-nk-qty-minus="${escapeAttr(item.key)}">−</button><span>${item.quantity}</span><button type="button" data-nk-qty-plus="${escapeAttr(item.key)}">+</button></div>`;
    const remove = `<button type="button" class="nk-remove-item" data-nk-remove="${escapeAttr(item.key)}" aria-label="Entfernen">×</button>`;

    if (isPage) {
      return `<div class="nk-cart-page-row" data-key="${escapeAttr(item.key)}"><div class="nk-cart-product">${img}<div><small>Dein Nachklang</small>${title}${purchase}</div></div><div>${money(item.price)}</div><div>${controls}</div><div><strong>${money(total)}</strong>${remove}</div></div>`;
    }
    return `<div class="nk-side-cart-item" data-key="${escapeAttr(item.key)}"><div class="nk-cart-product">${img}<div>${title}${purchase}<div class="nk-side-item-price">${money(item.price)}</div>${controls}</div></div>${remove}</div>`;
  };

  function renderAll() {
    const cart = readCart();
    const t = totals(cart);

    document.querySelectorAll('[data-nk-cart-count]').forEach(el => el.textContent = t.count);
    document.querySelectorAll('[data-nk-cart-subtotal]').forEach(el => el.textContent = money(t.subtotal));

    document.querySelectorAll('[data-nk-cart-items]').forEach(el => {
      el.innerHTML = cart.items.map(item => itemTemplate(item, false)).join('');
    });
    document.querySelectorAll('[data-nk-cart-page-items]').forEach(el => {
      el.innerHTML = cart.items.map(item => itemTemplate(item, true)).join('');
    });

    document.querySelectorAll('[data-nk-cart-empty]').forEach(el => {
      el.style.display = cart.items.length ? 'none' : 'block';
    });
    document.querySelectorAll('.nk-cart-summary, .nk-cart-page-summary').forEach(el => {
      el.style.display = cart.items.length ? '' : 'none';
    });
  }

  function openSideCart() {
    document.documentElement.classList.add('nk-side-cart-open');
    document.querySelectorAll('.nk-side-cart').forEach(el => el.setAttribute('aria-hidden', 'false'));
  }
  function closeSideCart() {
    document.documentElement.classList.remove('nk-side-cart-open');
    document.querySelectorAll('.nk-side-cart').forEach(el => el.setAttribute('aria-hidden', 'true'));
  }

  function escapeHtml(str) {
    return String(str || '').replace(/[&<>'"]/g, s => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[s]));
  }
  function escapeAttr(str) { return escapeHtml(str); }

  document.addEventListener('click', function (e) {
    const addBtn = e.target.closest('.nk-add-to-cart-btn');
    if (addBtn) {
      const wrap = addBtn.closest('.nk-add-to-cart-wrap');
      const qtyInput = wrap ? wrap.querySelector('.nk-add-to-cart-qty') : null;
      let product = {};
      try { product = JSON.parse(addBtn.getAttribute('data-product') || '{}'); } catch (err) {}
      const choice = wrap ? wrap.querySelector('.nk-purchase-option input[type="radio"]:checked') : null;
      if (choice) {
        product.purchase_type = choice.value || 'self';
        product.purchase_label = choice.getAttribute('data-label') || (product.purchase_type === 'gift' ? 'Als Geschenk' : 'Für mich');
      }
      const qty = qtyInput ? qtyInput.value : 1;
      if (!product.variant_id) {
        alert('Dieses Produkt hat noch keine Variant ID. Bitte ACF Feld variant_id prüfen.');
        return;
      }
      api.add(product, qty);
      renderAll();
      if (addBtn.getAttribute('data-open-cart') === '1') openSideCart();
      return;
    }

    if (e.target.closest('.nk-cart-trigger')) { renderAll(); openSideCart(); return; }
    if (e.target.closest('[data-nk-cart-close]')) { closeSideCart(); return; }

    const addQty = e.target.closest('.nk-qty-plus');
    const subQty = e.target.closest('.nk-qty-minus');
    if (addQty || subQty) {
      const input = e.target.closest('.nk-add-qty')?.querySelector('input');
      if (input) input.value = Math.max(1, Number(input.value || 1) + (addQty ? 1 : -1));
      return;
    }

    const plus = e.target.closest('[data-nk-qty-plus]');
    const minus = e.target.closest('[data-nk-qty-minus]');
    const remove = e.target.closest('[data-nk-remove]');
    if (plus || minus || remove) {
      const key = (plus && plus.dataset.nkQtyPlus) || (minus && minus.dataset.nkQtyMinus) || (remove && remove.dataset.nkRemove);
      const cart = readCart();
      const item = cart.items.find(i => i.key === key);
      if (remove) api.remove(key);
      else if (item) api.update(key, Number(item.quantity || 1) + (plus ? 1 : -1));
      renderAll();
      return;
    }

    const checkout = e.target.closest('[data-nk-checkout]');
    if (checkout) {
      const holder = checkout.closest('[data-checkout-url]');
      const checkoutUrl = holder ? holder.getAttribute('data-checkout-url') : '';
      const payload = api.exportPayload();
      window.NKCartLastCheckoutPayload = payload;
      if (!checkoutUrl) {
        alert('Checkout ist vorbereitet, aber noch nicht verbunden. Warenkorb-Daten liegen in window.NKCart.exportPayload().');
        console.log('Nachklang checkout payload:', payload);
        return;
      }
      const separator = checkoutUrl.indexOf('?') === -1 ? '?' : '&';
      window.location.href = checkoutUrl + separator + 'cart_id=' + encodeURIComponent(payload.cart_id);
    }
  });

  window.addEventListener('nk-cart:updated', renderAll);
  document.addEventListener('DOMContentLoaded', renderAll);
})();
